import os
import io
import json
import math
import time
import numpy as np
import requests
from bs4 import BeautifulSoup
from flask import Flask, render_template, request, redirect, url_for
from pdfminer.high_level import extract_text
from openai import OpenAI

# ---------- Config ----------
EMBED_MODEL = os.getenv("EMBED_MODEL", "text-embedding-3-large")
TOP_K = int(os.getenv("TOP_K", "10"))
ADVISOR_PATH = os.getenv("ADVISOR_PATH", os.path.join(os.path.dirname(__file__), "advisors.json"))
EMBED_CACHE = os.getenv("EMBED_CACHE", os.path.join(os.path.dirname(__file__), "embeddings", "advisor_embeddings.json"))

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

app = Flask(__name__)

def cosine(a: np.ndarray, b: np.ndarray) -> float:
    denom = (np.linalg.norm(a) * np.linalg.norm(b))
    if denom == 0: return 0.0
    return float(np.dot(a, b) / denom)

def embed_text(text: str) -> np.ndarray:
    text = text.strip().replace("\n", " ")
    resp = client.embeddings.create(model=EMBED_MODEL, input=text)
    return np.array(resp.data[0].embedding, dtype=np.float32)

def load_advisors():
    with open(ADVISOR_PATH, "r") as f:
        return json.load(f)

def ensure_advisor_embeddings(advisors):
    # If cache exists and matches count, load it
    if os.path.exists(EMBED_CACHE):
        try:
            with open(EMBED_CACHE, "r") as f:
                data = json.load(f)
            if isinstance(data, dict) and "model" in data and "items" in data and len(data["items"]) == len(advisors):
                return data
        except Exception:
            pass
    # Compute embeddings and cache
    items = []
    for a in advisors:
        text = f"Advisor #{a['id']}. Sectors: {', '.join(a['sectors'])}. {a['description']}"
        vec = embed_text(text).tolist()
        items.append({"id": a["id"], "embedding": vec})
        time.sleep(0.2)  # gentle pacing
    payload = {"model": EMBED_MODEL, "items": items}
    os.makedirs(os.path.dirname(EMBED_CACHE), exist_ok=True)
    with open(EMBED_CACHE, "w") as f:
        json.dump(payload, f)
    return payload

def fetch_linkedin_text(url: str) -> str:
    # NOTE: LinkedIn may block scraping. This is best-effort for public profiles.
    try:
        headers = {"User-Agent": "Mozilla/5.0 (AdvisorMatcher/1.0)"}
        r = requests.get(url, headers=headers, timeout=10)
        if r.status_code != 200:
            return ""
        soup = BeautifulSoup(r.text, "html.parser")
        # crude text extraction
        for s in soup(["script", "style", "noscript"]):
            s.extract()
        text = " ".join(soup.get_text(separator=" ").split())
        # Trim to reasonable size for embeddings
        return text[:8000]
    except Exception:
        return ""

def extract_pdf_text(file_storage) -> str:
    try:
        tmp_path = os.path.join(app.instance_path, "upload.pdf")
        os.makedirs(app.instance_path, exist_ok=True)
        file_storage.save(tmp_path)
        text = extract_text(tmp_path)
        return text[:16000]
    except Exception as e:
        return ""

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        return redirect(url_for('match'))
    return render_template("index.html")

@app.route("/match", methods=["POST"])
def match():
    advisors = load_advisors()
    cache = ensure_advisor_embeddings(advisors)

    resume_text = ""
    linkedin_url = request.form.get("linkedin", "").strip()
    goals = request.form.get("goals", "").strip()
    fallback = request.form.get("fallback_text", "").strip()

    if "resume" in request.files and request.files["resume"] and request.files["resume"].filename:
        resume_text = extract_pdf_text(request.files["resume"])

    if not resume_text and linkedin_url:
        resume_text = fetch_linkedin_text(linkedin_url)

    if not resume_text and fallback:
        resume_text = fallback

    user_text = (resume_text + "\n\nGOALS:\n" + goals).strip()
    if not user_text:
        user_text = "Student with unspecified resume text. GOALS: None provided."

    user_vec = embed_text(user_text)

    # Build a dict for quick lookup
    adv_by_id = {a["id"]: a for a in advisors}

    matches = []
    for item in cache["items"]:
        adv = adv_by_id.get(item["id"])
        if not adv: 
            continue
        adv_vec = np.array(item["embedding"], dtype=np.float32)
        score = cosine(user_vec, adv_vec)
        matches.append({
            "id": adv["id"],
            "sectors": adv["sectors"],
            "description": adv["description"],
            "headline": ", ".join(adv["sectors"][:3]),
            "score": score
        })

    matches.sort(key=lambda x: x["score"], reverse=True)
    topn = matches[:TOP_K]
    return render_template("results.html", matches=topn)

if __name__ == "__main__":
    app.run(debug=True)
