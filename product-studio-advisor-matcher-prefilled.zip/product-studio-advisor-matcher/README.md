# Product Studio Advisor Matcher

A lightweight Flask web app that takes a **resume PDF or LinkedIn URL** plus **user goals**, 
and returns **5–10 best-matching advisors** using OpenAI embeddings.

## Quick start

1. **Prereqs**
   - Python 3.9+
   - An OpenAI API key (set `OPENAI_API_KEY` in your environment).

2. **Install**
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

3. **Run**
```bash
export OPENAI_API_KEY=your_key_here  # Windows: set OPENAI_API_KEY=your_key_here
flask --app app.py run --debug
# then visit http://127.0.0.1:5000
```

## Notes

- The first run will compute embeddings for all advisors and cache them in `embeddings/advisor_embeddings.json`.
- If LinkedIn blocks scraping, paste your LinkedIn **Save as PDF** or paste profile text into the optional text area.
- Model defaults to `text-embedding-3-large`. You can switch in `app.py` if desired.
